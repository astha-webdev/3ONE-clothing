3ONE — Complete Front-End Website Prototype

HOW TO OPEN
1. Extract the ZIP folder.
2. Open the folder.
3. Double-click index.html. It opens in your browser.

WHAT IS INCLUDED
- Responsive desktop and mobile layout
- Home, Collection, Our Story and Contact sections
- Product category filters
- Add-to-bag interaction and subtotal
- Mobile navigation
- Newsletter form demo

IMPORTANT BEFORE CLIENT LAUNCH
- Replace sample product names, prices and images with the client's real products.
- Update the contact email and social links.
- Connect a real checkout/payment system and backend if online ordering is required.
- Product images and Google Fonts load from the internet, so an internet connection is needed for those assets.

This is a complete front-end prototype, not a live hosted URL or payment-enabled store.
